#!/bin/bash
# =============================================================================
# TIESSE Matrix Network - Version Update Script (COMPLETE)
# Updates version in ALL files that need it
# Usage: ./update-version.sh <new_version>
# Example: ./update-version.sh 4.1.004
# =============================================================================

if [ -z "$1" ]; then
    echo "❌ Usage: $0 <new_version>"
    echo "   Example: $0 4.1.004"
    exit 1
fi

NEW_VERSION="$1"
OLD_VERSION=$(grep -oP "CURRENT_VERSION = '\K[^']+" js/app.js 2>/dev/null || echo "unknown")

echo "=============================================================="
echo "TIESSE Matrix Network - Version Update (COMPLETE)"
echo "=============================================================="
echo "Old version: $OLD_VERSION"
echo "New version: $NEW_VERSION"
echo ""

# All files that contain version strings
declare -a FILES=(
    # JavaScript modules
    "js/app.js"
    "js/auth.js"
    "js/dashboard.js"
    "js/device-detail.js"
    "js/editlock.js"
    "js/features.js"
    "js/floorplan.js"
    "js/icons.js"
    "js/json-validator.js"
    "js/recovery.js"
    "js/ui-updates.js"
    
    # PHP backends
    "data.php"
    "api/auth.php"
    "api/editlock.php"
    "api/guacamole.php"
    "config/config.php"
    
    # HTML & CSS
    "index.html"
    "css/styles.css"
    
    # Configuration & Metadata
    "package.json"
    "README.md"
    "VERSION.txt"
    "VERSION_HISTORY.txt"
    "FINAL_STATUS_2026-02-12.txt"
    ".env.example"
    
    # Documentation
    "doc/BLUEPRINT.md"
)

echo "📝 Updating version strings in files..."
for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        # Replace OLD_VERSION with NEW_VERSION
        sed -i "s/${OLD_VERSION}/${NEW_VERSION}/g" "$file"
        
        # Count occurrences for verification
        count=$(grep -c "$NEW_VERSION" "$file" 2>/dev/null || echo "0")
        
        if [ "$count" -gt 0 ]; then
            echo "  ✅ $file ($count occurrences)"
        else
            echo "  ⚠️  $file (not updated or file may not contain version)"
        fi
    else
        echo "  ⚠️  $file not found"
    fi
done

echo ""
echo "=============================================================="
echo "VERIFICATION & SPECIAL UPDATES"
echo "=============================================================="

# Update SUPPORTED_VERSIONS in app.js (add new version if not present)
echo "📋 Checking SUPPORTED_VERSIONS in app.js..."
if grep -q "SUPPORTED_VERSIONS = \['$NEW_VERSION'" js/app.js; then
    echo "  ✅ SUPPORTED_VERSIONS already includes $NEW_VERSION"
else
    # Add new version to beginning of SUPPORTED_VERSIONS array
    sed -i "s/SUPPORTED_VERSIONS = \['/SUPPORTED_VERSIONS = ['$NEW_VERSION', '/" js/app.js
    echo "  ✅ Added $NEW_VERSION to SUPPORTED_VERSIONS"
fi

# Display key version declarations
echo ""
echo "🔍 CURRENT_VERSION in app.js:"
grep "var CURRENT_VERSION" js/app.js | head -1

echo ""
echo "📦 SUPPORTED_VERSIONS array:"
grep "var SUPPORTED_VERSIONS" js/app.js | head -c 100
echo "..."

echo ""
echo "📊 Summary of updates:"
echo "  Total files updated: ${#FILES[@]}"
echo "  Target version: $NEW_VERSION"
echo "  Version strings found: $(grep -r "$NEW_VERSION" --include="*.js" --include="*.php" --include="*.css" --include="*.html" --include="*.txt" --include="*.md" . --exclude-dir=node_modules --exclude-dir=Archives 2>/dev/null | wc -l)"
echo "  Cache-busting (index.html): $(grep -c "?v=$NEW_VERSION" index.html 2>/dev/null || echo "0")"

echo ""
echo "✅ Version update complete!"
echo ""
echo "📌 Next steps:"
echo "   1. Verify changes: git diff"
echo "   2. Commit: git add -A && git commit -m 'Version bump to $NEW_VERSION'"
echo "   3. Create backup: tar --exclude='node_modules' --exclude='.git' -czf ../matrix-v${NEW_VERSION}.tar.gz ."
echo "   4. Push: git push origin main"
