<?php
/**
 * TIESSE Matrix Network - Configuration
 * Version: 3.0.0
 */

// Prevent direct access
if (basename($_SERVER['PHP_SELF']) === 'config.php') {
    http_response_code(403);
    exit('Access denied');
}

// =============================================================================
// AUTHENTICATION
// =============================================================================

// Username for edit mode
define('AUTH_USERNAME', 'tiesse');

// Password hash (generated with password_hash('tiesseadm', PASSWORD_DEFAULT))
// To change password, run: php -r "echo password_hash('newpassword', PASSWORD_DEFAULT);"
define('AUTH_PASSWORD_HASH', '$2y$10$e1nfIfvV2sZag1oARGD89.bG9emt6QxSQyHoreh9Ep5cFrFpgXlpm');

// Session timeout in seconds (8 hours)
define('SESSION_TIMEOUT', 28800);

// =============================================================================
// PATHS
// =============================================================================

define('DATA_DIR', __DIR__ . '/../data/');
define('DATA_FILE', DATA_DIR . 'network_manager.json');

// =============================================================================
// SECURITY
// =============================================================================

// Start session with secure settings
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start([
            'cookie_httponly' => true,
            'cookie_samesite' => 'Strict',
            'gc_maxlifetime' => SESSION_TIMEOUT
        ]);
    }
}

// Check if user is authenticated
function isAuthenticated() {
    initSession();
    
    if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
        return false;
    }
    
    // Check session timeout
    if (isset($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
            // Session expired
            session_destroy();
            return false;
        }
        $_SESSION['last_activity'] = time();
    }
    
    return true;
}

// Verify password
function verifyPassword($password) {
    return password_verify($password, AUTH_PASSWORD_HASH);
}
