# TIESSE Matrix Network v4.0.000 - Migration Plan

**Date:** February 10, 2026  
**From:** v3.6.037 → v4.0.000  
**Working Directory:** /Matrix4/  
**Backup:** /Matrix-versaoatual/ (untouched)

---

## IMPLEMENTATION STATUS

| Component | Status | Files Modified |
|-----------|--------|----------------|
| Device Prefix/Sigla System | ✅ DONE | app.js, index.html, ui-updates.js, features.js, device-detail.js, dashboard.js, floorplan.js |
| New Device Types (WLC, DVR, PoE, IoT, TST) | ✅ DONE | app.js (VALID_ENUMS), index.html (select), features.js (colors/labels/badges) |
| Custom Prefix Creation UI | ✅ DONE | app.js (showCustomPrefixDialog, SweetAlert2) |
| Prefix in JSON Export/Import | ✅ DONE | app.js (exportJSON, importJSON, serverLoad, saveToStorage) |
| Auto-prefix Migration | ✅ DONE | app.js (normalizeDataCase auto-populates prefix from type) |
| UI Italian Labels | ✅ DONE | index.html (form labels), features.js (typeLabels) |
| Groups System | ✅ DONE | app.js (16 functions), index.html (deviceGroup select, Group Manager) |
| Groups Persistence | ✅ DONE | app.js (serverSave, saveToStorage, saveNow, loadFromStorage, serverLoad, exportJSON, importData) |
| Groups Auto-Migration | ✅ DONE | app.js (migrateToGroupSystem: 11 groups from 101 devices' rackId values) |
| Location Enhancements | ⏳ TODO | — |
| WallJack/External Cleanup | ⏳ TODO | — |
| Connection Form Simplification | ⏳ TODO | — |
| Monitoring Engine | ⏳ TODO | — |
| New Device Fields (DHCP, MAC, SN, hostname) | ⏳ TODO | — |

---

## LANGUAGE CONVENTION

| Layer | Language | Example |
|-------|----------|---------|
| Code (JS variables, functions, comments) | 🇬🇧 English | `monitoring.enabled`, `saveDevice()` |
| Data (JSON keys, field names) | 🇬🇧 English | `"isRack": true`, `"serialNumber": ""` |
| UI (labels, tooltips, messages, placeholders) | 🇮🇹 Italian | `"📡 Monitorato"`, `"Dispositivo aggiunto"` |
| Documentation (/doc/) | 🇬🇧 English | This file |

---

## PHASE 1: DATA MODEL - New Hierarchy

### 1.1 New `groups` Array in appState

**Currently:** `rackId` is a free-text field in each device. No independent group entity exists.  
**Change:** Create `appState.groups[]` as independent entities.

```javascript
// NEW: appState.groups[]
{
  id: "grp-uuid",              // Unique ID (auto-generated)
  locationId: "loc-00",        // Parent location ID (required)
  code: "RACK-NETWORK-01",     // Short code (can repeat across locations)
  name: "Rack Network 01",     // Descriptive name
  description: "",             // Optional description (e.g., "Solo dispositivi VoIP")
  isRack: true,                // Is this group a physical rack?
  rackUnits: 42,               // If isRack=true, how many U (optional)
  color: "#3b82f6",            // Color for UI
  order: 1                     // Sort order within location
}
```

**Unique identifier:** `locationId + code` (same code in different locations = different groups)

**Migration of existing data:**
- Extract unique `rackId` values from all devices
- Create one group per unique `rackId`, assigned to the device's location
- Replace `device.rackId` (string) → `device.groupId` (reference to group.id)

### 1.2 Enhanced `locations` Array

**Currently:** Locations exist but cannot be created empty.  
**Change:** Allow empty locations + virtual type + isolation flag.

```javascript
// ENHANCED: appState.locations[]
{
  id: "loc-00",                 // Unique ID (existing format kept)
  siteId: "main",              // Site reference
  code: "00",                  // Short code
  name: "Sala Server",         // Descriptive name
  type: "physical",            // "physical" | "virtual" ← NEW VALUES
  roomRef: "0",                // Reference to room polygon (null if virtual)
  color: "#7c3aed",
  isIsolated: false,           // NEW: If true, excluded from global reports/cascades
  showInFloorPlan: true        // NEW: Whether to show on floor plan map
}
```

**New fields:**
| Field | Type | Default | Purpose |
|-------|------|---------|---------|
| `type` | string | `"physical"` | `"physical"` or `"virtual"` (replaces old `"mapped"`/`"custom"`) |
| `isIsolated` | boolean | `false` | Isolate from global cascades/reports |
| `showInFloorPlan` | boolean | `true` | Show/hide on floor plan |

**Migration:**
- Existing `type: "mapped"` → `type: "physical"`, `showInFloorPlan: true`
- Existing `type: "custom"` → `type: "virtual"`, `showInFloorPlan: false`

---

## PHASE 2: DEVICE FORM - New Fields

### 2.1 New Fields Added to Device

| Field | JSON Key | Type | Required | Default | UI Label (IT) |
|-------|----------|------|----------|---------|---------------|
| Group | `groupId` | string | Yes | `""` | 🗂️ Gruppo * |
| DHCP toggle | `isDhcp` | boolean | No | `false` | 🔄 DHCP |
| MAC Address | `macAddress` | string | No | `""` | 🔗 MAC Address |
| Serial Number | `serialNumber` | string | No | `""` | 🔖 Numero di Serie |
| Hostname | `hostname` | string | No | `""` | 🏷️ Hostname |
| Asset Tag | `assetTag` | string | No | `""` | 📋 Etichetta Patrimonio |
| DNS 1 | `dns1` | string | No | `""` | DNS Primario |
| DNS 2 | `dns2` | string | No | `""` | DNS Secondario |
| Monitoring | `monitoringEnabled` | boolean | No | `false` | 📡 Monitorato |
| Monitoring Method | `monitoringMethod` | string | No | `"auto"` | Metodo di Monitoraggio |

### 2.2 Updated Device Data Model

```javascript
// COMPLETE device structure v4.0.000
{
  // Identity
  id: 1,                               // Numeric ID (auto-increment) - KEPT
  name: "SW-Core-01",                  // Device name - KEPT
  hostname: "",                         // NEW: FQDN
  brandModel: "Cisco C9300-48P",       // Brand + Model - KEPT
  type: "switch",                      // Device type - KEPT
  serialNumber: "",                     // NEW: Serial number
  assetTag: "",                         // NEW: Asset tag
  macAddress: "",                       // NEW: Primary MAC address

  // Hierarchy (CHANGED)
  locationId: "loc-00",                // NEW: Reference to location.id (replaces location string)
  groupId: "grp-uuid",                // NEW: Reference to group.id (replaces rackId string)
  position: 1,                         // RENAMED from "order"
  rackPosition: "front",              // NEW: "front" | "rear" | "standalone" (replaces isRear boolean)

  // Status
  status: "active",                    // KEPT: active|disabled|maintenance

  // Network (ENHANCED)
  isDhcp: false,                       // NEW: If true, IP is dynamic
  addresses: [{
    network: "10.10.100.1/24",         // KEPT
    ip: "",                            // KEPT (legacy)
    vlan: null,                        // KEPT
    zone: "LAN"                        // KEPT
  }],
  gateway: "",                         // KEPT
  mask: "",                            // KEPT
  dns1: "",                            // NEW
  dns2: "",                            // NEW

  // Ports - KEPT
  ports: [{
    name: "eth01",
    type: "eth",
    status: "active"
  }],

  // Links - KEPT
  links: [{
    type: "ssh",
    url: "10.10.100.1",
    label: "ssh"
  }],

  // Monitoring (NEW)
  monitoringEnabled: false,            // NEW: Is this device monitored?
  monitoringMethod: "auto",            // NEW: "snmp" | "ping" | "uptime_kuma" | "manual" | "auto"

  // Metadata - KEPT
  service: "",
  notes: ""
}
```

### 2.3 Fields REMOVED from Device

| Field | Reason |
|-------|--------|
| `rackId` | Replaced by `groupId` (reference to group entity) |
| `order` | Renamed to `position` |
| `isRear` | Replaced by `rackPosition` ("front"/"rear"/"standalone") |
| `location` (string) | Replaced by `locationId` (reference to location entity) |
| `rack` | Was duplicate of `rackId`, already deprecated |
| `rear` | Was duplicate of `isRear`, already deprecated |

### 2.4 Device Form Layout (HTML)

```
┌─────────────────────────────────────────────────────────────────────┐
│ + Aggiungi Dispositivo                                              │
├─────────────────────────────────────────────────────────────────────┤
│ ROW 1: Hierarchy                                                    │
│ [📍 Posizione *] [🗂️ Gruppo *] [🔢 Ordine] [Posizione Rack ▼]     │
│                                                                     │
│ ROW 2: Identity                                                     │
│ [📟 Nome Disp. *] [🔧 Marca/Modello] [🏷️ Tipo ▼] [⚡ Stato ▼]    │
│                                                                     │
│ ROW 3: Extended Identity                                            │
│ [🏷️ Hostname] [🔖 N. di Serie] [📋 Etichetta Patrim.] [🔗 MAC]   │
│                                                                     │
│ ROW 4: Service + Network Box + Ports Box + Links Box                │
│ [⚙️ Servizio]                                                       │
│ ┌─ 🌐 Rete ──────────────────────┐                                 │
│ │ [✓ DHCP] ← toggle              │                                 │
│ │ [IP/CIDR] [Zona ▼] [✕] [+]    │                                 │
│ │ [Gateway]  [Maschera]          │                                 │
│ │ [DNS Primario] [DNS Secondario]│                                 │
│ └─────────────────────────────────┘                                 │
│ ┌─ 🔌 Porte ─┐ ┌─ 🔗 Link ─┐                                     │
│ │ ...         │ │ ...        │                                     │
│ └─────────────┘ └────────────┘                                     │
│                                                                     │
│ ROW 5: Monitoring + Notes                                           │
│ [📡 Monitorato ☐] [Metodo ▼] (visible only when checked)           │
│ [📝 Note]                                                           │
│                                                                     │
│ [+ Aggiungi] [Annulla] [Pulisci]                                   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## PHASE 3: WALLJACK & EXTERNAL - Normalized as Regular Devices

### 3.1 Problem

Currently walljack and external are treated as "special connections" with:
- `connection.isWallJack` (boolean flag)
- `connection.externalDest` (free-text destination)
- `connection.roomId` (room assignment)
- Virtual phantom devices created in topology
- **167 special-case code points** across 8 files

### 3.2 Solution

Walljack and External become **normal devices** with ports and standard connections.

**Before (WRONG):**
```
Switch.eth02 → connection(isWallJack=true, externalDest="Z15") → phantom
```

**After (CORRECT):**
```
Switch.eth02 → PatchPanel.eth05 → WallJack-Z15.port01 ↔ [cable A6] ↔ srv-vm-01.eth01
ISP-TIM.wan01 → Firewall.wan01
```

### 3.3 Fields REMOVED from Connection

| Field | Reason |
|-------|--------|
| `isWallJack` | Walljack is now a regular device |
| `externalDest` | External/ISP is now a regular device |
| `roomId` | Device's `locationId` handles this |

### 3.4 Connection Data Model (Simplified)

```javascript
// SIMPLIFIED connection v4.0.000
{
  id: "c-xxxxxxxxxxxx",        // UUID - KEPT
  from: 1,                     // Source device ID - KEPT
  fromPort: "eth24",           // Source port - KEPT
  to: 2,                       // Destination device ID - KEPT (always a real device now)
  toPort: "eth01",             // Destination port - KEPT
  type: "trunk",               // Connection type - KEPT
  status: "active",            // KEPT
  cableColor: "#3b82f6",       // KEPT
  cableMarker: "A1",           // KEPT
  notes: ""                    // KEPT
}
```

### 3.5 HTML Changes - Connection Form

**REMOVED elements:**
- `<option value="walljack">` from toDevice select
- `<option value="external">` from toDevice select
- `<div id="externalDestContainer">` (entire section)
- `<div id="wallJackRoomContainer">` (entire section)
- `<input id="externalDest">`
- `<select id="wallJackRoomId">`

**Result:** Connection form becomes a simple from→to device picker with no special cases.

### 3.6 Code Cleanup (167 references)

| File | References to Remove/Simplify | Lines Affected |
|------|-------------------------------|----------------|
| js/app.js | 49 | isWallJack checks, externalDest logic, toggleExternalDest(), populateWallJackRoomSelect() |
| js/ui-updates.js | 25 | Special rendering for WJ/External in tables, matrix, rack view |
| js/features.js | 70 | Virtual device creation, wallJackMap, externalMap, special topology routing |
| js/device-detail.js | 3 | externalDest in tooltips and connection list |
| js/floorplan.js | 3 | WJ room filtering |
| js/json-validator.js | 3 | isWallJack validation |
| js/dashboard.js | 5 | WJ/external search and display |
| index.html | 9 | DOM elements, sample data, help text |

### 3.7 Data Migration

For each connection with `isWallJack: true`:
1. Check if a walljack device already exists with matching name/externalDest
2. If not, create a new device `{ type: "walljack", name: externalDest, ... }`
3. Convert the connection to a normal device-to-device connection
4. Remove `isWallJack`, `externalDest`, `roomId` from the connection

For each connection with `externalDest` and no `isWallJack`:
1. Check if an ISP/external device already exists
2. If not, create a new device `{ type: "isp", name: externalDest, ... }`
3. Convert to normal connection
4. Remove `externalDest`

---

## PHASE 4: CONNECTIONS - Rebuilt with New Hierarchy

### 4.1 Connection Form Changes

After Phase 3 cleanup, the connection form is simplified:

```
┌─ Connessione ──────────────────────────────────────────────────────┐
│                                                                     │
│ SORGENTE                          DESTINAZIONE                      │
│ [📍 Posizione ▼]                  [📍 Posizione ▼]                 │
│ [🗂️ Gruppo ▼]                     [🗂️ Gruppo ▼]                    │
│ [📟 Dispositivo * ▼]              [📟 Dispositivo * ▼]             │
│ [🔌 Porta * ▼]                    [🔌 Porta * ▼]                   │
│                                                                     │
│ DETTAGLI                                                            │
│ [Tipo Connessione ▼] [Stato ▼]                                     │
│ [🎨 Colore Cavo] [🏷️ Etichetta Cavo]                              │
│ [📝 Note]                                                           │
│                                                                     │
│ [+ Aggiungi Connessione] [Annulla] [Pulisci]                       │
└─────────────────────────────────────────────────────────────────────┘
```

**No more special cases.** Every connection is device-to-device.

---

## PHASE 5: TOPOLOGY / MATRIX / FLOOR PLAN - Updated

### 5.1 Topology

- Remove virtual walljack/external device creation (~100 lines in features.js)
- All devices are real → render normally
- WallJack devices show with walljack icon (already exists)
- ISP/External devices show with isp/external icon (already exists)

### 5.2 Matrix

- Remove special WJ/External rows/columns
- All devices are in the standard matrix grid

### 5.3 Floor Plan

- WallJack devices belong to a location → show in that room
- Remove special `roomId` connection logic
- Use standard `device.locationId` → room mapping

---

## PHASE 6: MONITORING (Future - After Phases 1-5)

### 6.1 Device Monitoring Fields

```javascript
monitoringEnabled: false,          // Toggle in device form
monitoringMethod: "auto"           // "snmp" | "ping" | "uptime_kuma" | "manual" | "auto"
```

### 6.2 Schedule System (appState.monitoring)

```javascript
appState.monitoring = {
  config: { enabled: true, defaultInterval: 3600, ... },
  schedules: [{ scope, interval, method, runDays, runHours, notify }],
  portStates: [{ deviceId, port, matrixStatus, realStatus, mismatch }],
  alerts: [{ type, severity, deviceId, port, expected, actual, status }]
}
```

### 6.3 Integration Points
- **A) SNMP** via LibreNMS API → Managed switches, routers, firewalls
- **B) Ping/ARP** → PCs, TVs, phones, unmanaged devices
- **C) Uptime Kuma** API → Services (HTTP, SSH, DNS, DB)

### 6.4 Alert Types
| Code | Situation | Required Action |
|------|-----------|----------------|
| `UNDOCUMENTED_UP` | Port UP but no connection in Matrix | Document the connection |
| `DOCUMENTED_DOWN` | Connection exists but port is DOWN | Check cable or remove connection |
| `MAC_CHANGED` | Different MAC on port | Verify device swap |
| `DEVICE_UNREACHABLE` | Entire device not responding | Check power/network |

---

## FILE CHANGE SUMMARY

### Files MODIFIED

| File | Changes |
|------|---------|
| `index.html` | New form fields (DHCP, MAC, SN, hostname, monitoring), remove WJ/ext special UI, update labels to Italian |
| `js/app.js` | New data model, saveDevice() expanded, editDevice() expanded, clearDeviceForm() expanded, remove 49 WJ/ext references, add group management functions |
| `js/ui-updates.js` | Remove 25 WJ/ext references, update table columns, add new fields to device rows |
| `js/features.js` | Remove 70 WJ/ext references (virtual devices, special topology), simplify connection rendering |
| `js/device-detail.js` | Add new fields to modal (MAC, SN, hostname, DHCP, monitoring badge), remove 3 externalDest refs |
| `js/floorplan.js` | Remove 3 WJ refs, use locationId for device-room mapping |
| `js/json-validator.js` | Update schema validation for new fields, remove isWallJack validation |
| `js/dashboard.js` | Remove 5 WJ/ext refs, update search to include new fields |
| `package.json` | Version 4.0.000 (already done) |

### Files NOT MODIFIED

| File | Reason |
|------|--------|
| `js/auth.js` | No changes needed |
| `js/editlock.js` | No changes needed |
| `js/icons.js` | walljack and external icons KEPT (they're still valid device types) |
| `css/styles.css` | No changes needed |
| `server.js` | No changes needed |
| `data.php` | No changes needed |

### Data Migration (`network_manager.json`)

| Action | Details |
|--------|---------|
| Create `groups[]` | Extract from existing `rackId` values |
| Update `locations[]` | Add `isIsolated`, `showInFloorPlan`, normalize `type` |
| Update `devices[]` | `rackId` → `groupId`, `order` → `position`, `isRear` → `rackPosition`, `location` → `locationId`, add new empty fields |
| Update `connections[]` | Convert WJ/External to normal device-to-device, remove `isWallJack`, `externalDest`, `roomId` |
| Create new WJ devices | From `externalDest` data in walljack connections |
| Create new ISP devices | From `externalDest` data in external connections |

---

## IMPLEMENTATION ORDER

```
Phase 1: Data Model (groups, locations)
  ├── 1.1 Add groups[] to appState
  ├── 1.2 Enhance locations[] (virtual, isolated)
  ├── 1.3 Create Location Manager UI (create empty locations)
  └── 1.4 Create Group Manager UI (create empty groups)

Phase 2: Device Form
  ├── 2.1 Add new HTML fields (DHCP, MAC, SN, hostname, monitoring)
  ├── 2.2 Update saveDevice()
  ├── 2.3 Update editDevice()
  ├── 2.4 Update clearDeviceForm()
  ├── 2.5 Update device table rendering
  └── 2.6 Update Device Detail modal

Phase 3: WallJack/External Cleanup
  ├── 3.1 Remove special UI elements from index.html
  ├── 3.2 Clean app.js (49 references)
  ├── 3.3 Clean ui-updates.js (25 references)
  ├── 3.4 Clean features.js (70 references)
  ├── 3.5 Clean remaining files (14 references)
  └── 3.6 Write data migration function

Phase 4: Connections
  ├── 4.1 Simplify connection form
  └── 4.2 Update connection rendering

Phase 5: Views
  ├── 5.1 Update topology (no more virtual devices)
  ├── 5.2 Update matrix view
  └── 5.3 Update floor plan

Phase 6: Monitoring (future)
  ├── 6.1 Monitoring toggle in device form
  ├── 6.2 Schedule system
  ├── 6.3 LibreNMS/Ping/Uptime Kuma integration
  └── 6.4 Alert system
```

---

## VALIDATION CHECKLIST

Before each phase is complete, verify:

- [ ] Server starts without errors (`node server.js`)
- [ ] Page loads without console errors
- [ ] Existing data is preserved (101 devices, 93 connections)
- [ ] New fields save and load correctly
- [ ] Edit mode populates all fields
- [ ] Clear form resets all fields
- [ ] Device Detail modal shows new fields
- [ ] Topology renders correctly
- [ ] Matrix renders correctly
- [ ] Floor Plan renders correctly
- [ ] Export (JSON, Excel) includes new fields
- [ ] Import handles both old (v3.x) and new (v4.x) data formats

---

**Status:** AWAITING VALIDATION  
**Next Step:** Review this plan together, then begin Phase 1
