# Changelog — Tiesse Matrix Network

All notable changes to this project are documented in this file.  
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and [Semantic Versioning](https://semver.org/).

---

## [4.0.000] — 2026-02-11

### Added
- **Group Entity System**: Groups (`appState.groups[]`) are now first-class entities with: id, code, name, locationId, isRack, rackUnits, color, order, description
- **16 group functions**: `getGroupByCode()`, `getGroupById()`, `getGroupsForLocation()`, `groupSortFn()`, `generateGroupId()`, `createGroupEntity()`, `getGroupDisplayLabel()`, `getGroupColor()`, `migrateToGroupSystem()`, `updateGroupSelect()`, `onDeviceLocationChange()`, `quickAddGroup()`, `openGroupManager()`, `quickAddGroupFromManager()`, `editGroup()`, `deleteGroup()`
- **Group Manager UI**: SweetAlert2 modal showing groups organized by location, with create/edit/delete operations
- **Quick Add Group**: Button "+" next to group select — opens SweetAlert2 dialog to create a group on the fly with code, name, location, isRack, rackUnits
- **Location→Group cascade**: Changing location in device form auto-filters the group select
- **Auto-migration**: `migrateToGroupSystem()` extracts unique `rackId` values from devices and creates group entities (11 groups from 101 devices in real data)
- **Group persistence**: Groups saved/loaded via localStorage (`networkGroups`), server (`serverSave`/`serverLoad`), JSON export/import (`exportJSON`/`importData`)
- **Device Prefix System**: 26 standard prefixes (SW, RT, FW, SRV, etc.) displayed before device names everywhere — tables, cards, matrix, topology, floor plan, exports, tooltips, search results, print views
- **Custom Prefix Creation**: SweetAlert2 dialog to create user-defined prefixes with code, Italian label, and English tooltip
- **`getDeviceDisplayName(device)`**: Standard function for rendering device names with prefix across 45+ display points in 7 files
- **`getDeviceRawName(device)`**: Utility to extract name without prefix (for editing)
- **5 new device types**: `wlc` (Wireless Controller), `poe` (PoE Injector/Switch), `dvr` (DVR/NVR), `iot` (IoT Device), `tst` (Test Bench)
- **Prefix field in device form**: New `<select id="devicePrefix">` with auto-selection based on device type
- **Auto-prefix migration**: `normalizeDataCase()` automatically populates `prefix` from `type` for legacy devices
- **Custom prefixes persistence**: Saved/loaded via localStorage, JSON export/import, and server sync
- **Italian UI labels**: All device form labels, buttons, and messages translated to Italian
- **Professional documentation**: New `doc/README.md` with architecture, data model, conventions, API reference; `doc/CHANGELOG.md` (this file)
- **Documentation archive**: v3 docs archived to `doc/archive/v3/`

### Changed
- **Device form**: `rackId` text input → `deviceGroup` select (populated from group entities, with "+" quick-add and "⚙️" manager buttons)
- **Device form Location**: Added `onchange="onDeviceLocationChange()"` to cascade group filtering
- **Form buttons**: All buttons translated to Italian (Aggiungi, Annulla, Pulisci, Aggiorna)
- **Form labels**: All labels translated to Italian (Posizione, Gruppo, Ordine, Nome Dispositivo, Marca/Modello)
- `saveDevice()`: Reads group from `<select id="deviceGroup">`, syncs to hidden `rackId` field
- `editDevice()`: Calls `updateGroupSelect()` and sets group select value
- `clearDeviceForm()`: Resets group select, Italian button text
- `getGroupsByLocation()`: Now uses `appState.groups` entities (with fallback to legacy device scan)
- `serverSave()`: Includes `groups[]` and `nextGroupId` in payload
- `saveToStorage()` / `saveNow()`: Persist `groups[]` and `nextGroupId` to localStorage
- `loadFromStorage()`: Loads `networkGroups` and `nextGroupId` from localStorage
- `serverLoad()`: Loads groups from server data, calls `migrateToGroupSystem()`
- `exportJSON()`: Includes `groups[]` and `nextGroupId` in export payload
- `importData()`: Restores groups from import, calls `migrateToGroupSystem()`, includes in rollback state
- `initApp()`: Calls `migrateToGroupSystem()` and `updateGroupSelect()` after data load
- `updateUI()`: Calls `updateGroupSelect()` alongside other refresh functions
- `VALID_ENUMS.deviceTypes` expanded from 31 to 36 types
- `typeColors`, `typeLabels`, `typeBadgeColors` in `features.js` — added 5 new types, Italian labels
- `appState` JSDoc: Added Group schema documentation

### Files Modified
| File | Lines | Changes |
|------|-------|---------|
| `js/app.js` | 5,335 | +180 (prefix system, helpers, CRUD updates, persistence) |
| `index.html` | 4,169 | +20 (prefix field, new device types, Italian labels) |
| `js/ui-updates.js` | 2,792 | 21 display points updated to `getDeviceDisplayName()` |
| `js/features.js` | 4,893 | 5 display points + new type entries in 3 lookup objects |
| `js/device-detail.js` | 1,080 | 5 display points updated |
| `js/dashboard.js` | 1,210 | 3 display points updated |
| `js/floorplan.js` | 1,351 | 3 display points updated |
| `doc/README.md` | new | Complete v4 documentation |
| `doc/CHANGELOG.md` | new | This file |
| `doc/V4_MIGRATION_PLAN.md` | 491+ | Added implementation status table |

---

## [3.6.037] — 2026-02-10

> Last v3 release. Full history in `doc/archive/v3/`.

### Summary
- Final stable v3 release before v4 migration
- 101 devices, 93 connections, 22 locations, 22 rooms
- All v3 features functional: topology, matrix, floor plan, export, import
